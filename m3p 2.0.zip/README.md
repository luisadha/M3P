# M3P (Mkshrc Mood Mod Project)
# 
# Version

Usage
 "Rename the "Mkshrc Mood Mod Project" file with name "mkshrc" only, and then executing script by "sh setups" And enjoy terminating :)"

Requirements
- Busybox
- Su permissions granted

This patch include:
Main :
 1. fix all error known from mkshrc mod by @7175 XDA and build fpath folder.
 2. autoload like motd on termux! (al functions)
 3. prompt-style "ssh connection status" inspired by (dropbear) it's SimpleSSHD apps, enabled by default (disable using `logout').
 4. 'zsh' prompt like kali-linux, if we have zsh binnary (Required 5.0.5 version)

EXTRAS :
- the microsd alias for quick change directory to external storage(UT) /Micro SD Card.
- prompt you if using oldest version of mksh
- additional functions from me :)
- additional aliases from me :)
- unaliases some.
- and more...

Recomended Third Party Project
- Bash (nanodroid/nanomod)
- pexec, zsh, busybox.ndk and more files (from attachment "useful.bins" xda thread)
- toybox binnary
